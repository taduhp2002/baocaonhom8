﻿--Cho biết thông tin nhân viên (HONV, TENLOT, TENNV) có MaNV là số chẵn.
DECLARE @max int,@num int;
SELECT @max=MAX(CAST(MANV AS int))
FROM NHANVIEN
SET @num=1;
WHILE @num<=@max
BEGIN
	IF @num % 2 = 0
		SELECT MANV,HONV,TENLOT,TENNV
		FROM NHANVIEN
		WHERE CAST(MANV AS int) = @num;
	SET @num = @num +1;
END

--Cho biết thông tin nhân viên (HONV, TENLOT, TENNV) có MaNV là số chẵn nhưng không tính nhân viên có MaNV là 4.
DECLARE @ln int,@so int;
SELECT @ln=MAX(CAST(MANV AS int))
FROM NHANVIEN
SET @so=1;
WHILE @so<=@ln
BEGIN
	IF @so=4
	BEGIN
		SET @so = @so +1;
		CONTINUE;
	END
	IF @so % 2 = 0
		SELECT MANV,HONV,TENLOT,TENNV
		FROM NHANVIEN
		WHERE CAST(MANV AS int) = @so;
	SET @so = @so +1;
END
