﻿----Viết chương trình xem xét có tăng lương cho nhân viên hay không. Hiển thị cột thứ 1 là TenNV, cột thứ 2 nhận giá trị----
--“TangLuong” nếu lương hiện tại của nhân viên nhở hơn trung bình lương trong phòng mà nhân viên đó đang làm việc.
--“KhongTangLuong “ nếu lương hiện tại của nhân viên lớn hơn trung bình lương trong phòng mà nhân viên đó đang làm việc.

DECLARE @ThongKe TABLE(MaPB int,LuongTB float)
INSERT INTO @ThongKe
	SELECT PHG, AVG(LUONG)
	FROM NHANVIEN 
	GROUP BY PHG
SELECT TENNV,PHG,LUONG,LuongTB,TinhTrang=CASE
WHEN LUONG>LuongTB THEN 'Không tăng lương'
ELSE'Tăng lương'
END
FROM NHANVIEN a 
INNER JOIN @ThongKe b ON a.PHG=B.MaPB
----Viết chương trình phân loại nhân viên dựa vào mức lương----
--Nếu lương nhân viên nhỏ hơn trung bình lương mà nhân viên đó đang làm việc thì xếp loại “nhanvien”, ngược lại xếp loại “truongphong”
DECLARE @tbThongKe TABLE (MaPB int, LuongTB float)
INSERT INTO @tbThongKe
	SELECT PHG, AVG(Luong) FROM NHANVIEN GROUP BY PHG
SELECT TENNV, LUONG,
ChucVu = CASE
WHEN LUONG < LuongTB THEN 'Nhan Vien'
ELSE 'Truong Phong'
END
FROM NHANVIEN a inner join @tbThongKe b
ON a.PHG = b.MaPB

--.Viết chương trình hiển thị TenNV, tùy vào cột phái của nhân viên
SELECT TENNV = CASE
WHEN PHAI = 'Nam'THEN 'Mr. ' + TENNV 
WHEN PHAI = N'Nữ' THEN 'Ms. ' + TENNV 
END
FROM NHANVIEN

--Viết chương trình tính thuế mà nhân viên phải đóng theo công thức:
SELECT TENNV, LUONG,
Thue = CASE
	WHEN LUONG between 0 and 25000 THEN LUONG*0.1
	WHEN LUONG between 25000 and 30000 THEN LUONG*0.12
	WHEN LUONG between 30000 and 40000 THEN LUONG*0.15
	WHEN LUONG between 40000 and 50000 THEN LUONG*0.2
	ELSE LUONG*0.25 
	END
FROM NHANVIEN