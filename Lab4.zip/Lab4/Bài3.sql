﻿---Thực hiện chèn thêm một dòng dữ liệu vào bảng PhongBan theo 2 bước
--Nhận thông báo “ thêm dư lieu thành cong” từ khối Try
--Chèn sai kiểu dữ liệu cột MaPHG để nhận thông báo lỗi “Them dư lieu that bai” từ khối Catch
BEGIN TRY
	INSERT INTO PHONGBAN(TENPHG,MAPHG,TRPHG,NG_NHANCHUC)
		VALUES(N'Tài chính', 10,'123','2022-02-20');
	PRINT N'Thêm dữ liệu thành công';
END TRY
BEGIN CATCH
	PRINT N'Thêm dữ liệu thất bại'
END CATCH

---Viết chương trình khai báo biến @chia, thực hiện phép chia @chia cho số 0 và dùng RAISERROR để thông báo lỗi.
BEGIN TRY
  DECLARE @chia int;
  SET @chia=55 /0;
END TRY
BEGIN CATCH
 DECLARE @ErrorMessage nvarchar(2048), @ErrorServerity int, @ErrorState int;
 SELECT  @ErrorMessage = ERROR_MESSAGE(),
         @ErrorServerity= ERROR_SEVERITY(),
		 @ErrorState= ERROR_STATE();
 RAISERROR(@ErrorMessage,@ErrorServerity, @ErrorState);
END CATCH;
