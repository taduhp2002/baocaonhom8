﻿--1.Cho biết nhân viên có lương cao nhất.
SELECT 'Tên nhân viên'=TENNV,'Lương cao nhất'=LUONG
FROM NHANVIEN
WHERE LUONG=(SELECT MAX(LUONG) FROM NHANVIEN)

--2.Cho biết họ tên nhân viên (HONV, TENLOT, TENNV) có mức lương trên mức lương trung bình của phòng "Nghiên cứu”.
SELECT (NHANVIEN.HONV + ' ' + NHANVIEN.TENLOT + ' ' + NHANVIEN.TENNV) AS 'Họ tên nhân viên có lương trung bình trên mức lương trung bình của phòng "Nghiên cứu"'
FROM NHANVIEN
WHERE LUONG > (SELECT AVG(LUONG)FROM NHANVIEN, PHONGBAN WHERE PHG = MAPHG AND TENPHG = N'Nghiên cứu')

--3.Với các phòng ban có mức lương trung bình trên 30,000, liệt kê tên phòng ban và số lượng nhân viên của phòng ban đó.
SELECT 'Tên phòng ban'=TENPHG,COUNT(*) AS 'Số lượng nhân viên '
FROM PHONGBAN,NHANVIEN
WHERE MAPHG=PHG
GROUP BY TENPHG
HAVING AVG(LUONG)>30000

--4. Với mỗi phòng ban, cho biết tên phòng ban và số lượng đề án mà phòng ban đó chủ trì.
SELECT 'Tên phòng ban'=TENPHG  ,'Số lượng đề án'= COUNT(*) 
FROM PHONGBAN,DEAN
WHERE MAPHG=PHONG
GROUP BY TENPHG

 

