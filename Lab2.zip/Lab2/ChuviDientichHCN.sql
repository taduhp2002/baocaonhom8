﻿DECLARE @chieudai int, @chieurong int, @chuvi int, @dientich int
SET @chieudai=5
SET @chieurong=6
SET @chuvi = (@chieudai+@chieurong)*2
SET @dientich = @chieudai*@chieurong

SELECT 'Chu vi'= @chuvi, 'Diện tích' = @dientich