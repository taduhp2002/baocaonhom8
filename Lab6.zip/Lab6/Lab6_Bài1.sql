--R�ng bu?c khi th�m m?i nh�n vi�n th� m?c l??ng ph?i l?n h?n 15000, n?u vi ph?m th� xu?t th�ng b�o �luong ph?i >15000�
CREATE TRIGGER trig_bai1a on NHANVIEN 
FOR INSERT
AS
BEGIN
	IF exists(select * from NHANVIEN where LUONG < 15000)
	print N'L??ng ph?i > 15000'
	rollback transaction
END

INSERT INTO NHANVIEN VALUES('Ph?m','T?n','T�i','002','1975-02-12','H� N?i','Nam',14000,'002',2)

--R�ng bu?c khi th�m m?i nh�n vi�n th� ?? tu?i ph?i n?m trong kho?ng 18 <= tu?i <=65.
CREATE TRIGGER trig_Bai1b on NHANVIEN
FOR INSERT
AS
	DECLARE @tuoi int;
	SELECT @tuoi = convert(int, getDate()) - CONVERT(int,  YEAR(NGSINH)) from NHANVIEN
	IF exists(SELECT * FROM NHANVIEN WHERE @tuoi <18 or @tuoi > 65)
		BEGIN 
			print N'tu?i kh�ng h?p l? (trong kho?ng 18 - 65)'
			rollback transaction
		END

INSERT INTO NHANVIEN VALUES('Tr?n','V?n','An','011','2020-08-10','H� N?i','Nam',16000,'004',2)

--R�ng bu?c khi c?p nh?t nh�n vi�n th� kh�ng ???c c?p nh?t nh?ng nh�n vi�n ? TP HCM
CREATE TRIGGER trig_bai1c on NHANVIEN
FOR UPDATE
AS
	IF (SELECT DCHI FROM inserted) like '%HCM%'
	BEGIN
		print N'??a ch? kh�ng h?p l?'
		rollback transaction
	END
UPDATE NHANVIEN SET HONV = 'L�m' WHERE MANV = '007'
