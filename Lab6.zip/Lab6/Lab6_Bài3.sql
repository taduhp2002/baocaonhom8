--X�a c�c th�n nh�n trong b?ng th�n nh�n c� li�n quan khi th?c hi?n h�nh ??ng x�a nh�n vi�n trong b?ng nh�n vi�n.
create trigger trig_bai3a on NHANVIEN  instead of delete
as
begin
	delete THANNHAN where MA_NVIEN in (select MA_NVIEN from deleted)
	delete NHANVIEN where MANV in(select MANV from deleted);
end

delete from NHANVIEN where MANV = '015'

--Khi th�m m?t nh�n vi�n m?i th� t? ??ng ph�n c�ng cho nh�n vi�n l�m ?? �n c� MADA l� 1.
create trigger trig_bai3b on NHANVIEN instead of insert
as
begin
update PHANCONG
set MADA = 1
where MA_NVIEN in(select MANV from inserted)
end


