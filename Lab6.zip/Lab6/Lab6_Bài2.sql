--Hi?n th? t?ng s? l??ng nh�n vi�n n?, t?ng s? l??ng nh�n vi�n nam m?i khi c� h�nh ??ng th�m m?i nh�n vi�n.
create trigger trig_bai2a on NHANVIEN 
after insert
as
begin
	declare @Nam int, @Nu int
	select @Nam = count(*) From NHANVIEN where PHAI LIKE 'Nam'
	select @Nu = count(*) From NHANVIEN where PHAI LIKE N'N?'
	print N'T?ng s? l??ng nh�n vi�n	nam l�: '+ cast(@Nam as varchar)
	print N'T?ng s? l??ng nh�n vi�n	n? l�: '+  cast(@Nu as varchar)
end

--Hi?n th? t?ng s? l??ng nh�n vi�n n?, t?ng s? l??ng nh�n vi�n nam m?i khi c� h�nh ??ng c?p nh?t ph?n gi?i t�nh nh�n vi�n
create trigger trig_bai2b on NHANVIEN 
after update
as
begin
	declare @Nam int, @Nu int
	select @Nam = count(*) From NHANVIEN where PHAI LIKE 'Nam'
	select @Nu = count(*) From NHANVIEN where PHAI LIKE N'N?'
	print N'T?ng s? l??ng nh�n vi�n	nam l�: '+ cast(@Nam as varchar)
	print N'T?ng s? l??ng nh�n vi�n	n? l�: '+  cast(@Nu as varchar)
end

update NHANVIEN set PHAI = N'N?' where MANV = '004'

--Hi?n th? t?ng s? l??ng ?? �n m� m?i nh�n vi�n ?� l�m khi c� h�nh ??ng x�a tr�n b?ng DEAN
create trigger trig_bai3c on DEAN
after delete
as
begin
	select MA_NVIEN,count(MADA) as N'T?ng s? l??ng ?? �n m?i nv ?� l�m' FROM PHANCONG
	group by MA_NVIEN
end

delete DEAN where MADA = 24
