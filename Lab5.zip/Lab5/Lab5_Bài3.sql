﻿----Thêm phòng ban có tên CNTT vào csdl QLDA, các giá trị được thêm vào dưới dạng tham số đầu vào, kiếm tra nếu trùng Maphg thì thông báo thêm thất bại.
create proc ThemPB  
	@TenPhg nvarchar(20), @MaPhg int, @TrPhg nvarchar(10), @Ng_NhanChuc date
as 
begin
	if exists(select * from PHONGBAN where MAPHG = @MaPhg) 
	begin
		print(N'Thêm thất bại');
	end
	
	Insert into PHONGBAN
		(TENPHG,MAPHG,TRPHG,NG_NHANCHUC)
	Values
		(@TenPhg, @MaPhg, @TrPhg, @Ng_NhanChuc);
end

exec ThemPB 'CNTT', 11, '005', '2022-11-29'

----Cập nhật phòng ban có tên CNTT thành phòng IT.
CREATE PROC CapnhatPB
	@MaPB int, @TenPB nvarchar(15),
	@MaTP nvarchar(9), @NgayNhanChuc date
AS
BEGIN
	if(exists(select * from PHONGBAN where MAPHG = @MaPB ))
		update PHONGBAN set TENPHG = @TenPB, TRPHG = @MaTP, NG_NHANCHUC = @NgayNhanChuc
		where MAPHG = @MaPB
	else 
		begin
			insert into PHONGBAN(MAPHG, TENPHG, TRPHG, NG_NHANCHUC)
			values(@MaPB, @TenPB,@MaTP,@NgayNhanChuc)
			print N'Thêm thành công'
		end
END

exec CapnhatPB '11', 'IT', '005', '2020-11-29'

----Thêm một nhân viên vào bảng NhanVien, tất cả giá trị đều truyền dưới dạng tham số đầu vào với điều kiện:
-- nhân viên này trực thuộc phòng IT
--Nhận @luong làm tham số đầu vào cho cột Luong, nếu @luong<25000 thì nhân viên này do nhân viên có mã 009 quản lý, ngươc lại do nhân viên có mã 005 quản lý
--Nếu là nhân viên nam thi nhân viên phải nằm trong độ tuổi 18-65, nếu là nhân viên nữ thì độ tuổi phải từ 18-60.
create proc ThemNV
	@HONV nvarchar(15), @TENLOT nvarchar(15), @TENNV nvarchar(15),
	@MANV nvarchar(6), @NGSINH date, @DCHI nvarchar(50), @PHAI nvarchar(3),
	@LUONG float, @MA_NQL nvarchar(3) = null, @PHG int
as
begin
	declare @age int 
	set @age = YEAR(GETDATE()) - YEAR (@NGSINH)
	if @PHG = (select MAPHG from PHONGBAN where TENPHG = 'IT')
		begin
			if @LUONG < 25000
				set @MA_NQL = '009'
			else set @MA_NQL = '005'

			if (@PHAI = 'Nam' and (@age >= 18 and @age <= 65))
				or (@PHAI = N'Nữ' and (@age >= 18 and @age <= 60))
				begin
					insert into NHANVIEN(HONV, TENLOT, TENNV, MANV, NGSINH, DCHI, PHAI, LUONG, MA_NQL, PHG)
					values (@HONV, @TENLOT, @TENNV, @MANV, @NGSINH, @DCHI, @PHAI, @LUONG, @MA_NQL, @PHG)
				end
			else 
				print N'Không thuộc độ tuổi lao động'
		end
	else 
		print N'Không phải Phòng Ban IT'
end

exec ThemNV 'Nguyen', 'Van', 'Nam', '008', '1985-06-10', 'Da Nang', 'Nam', '25000', '004', '8'
exec ThemNV 'Nguyen', 'Van', 'Nam', '006', '2020-06-10', 'Da Nang', 'Nam', '25000', '004', '8'
exec ThemNV 'Nguyen', 'Van', N'Nữ', '005', '1954-06-10', 'Da Nang', 'Nam', '25000', '004', '8'