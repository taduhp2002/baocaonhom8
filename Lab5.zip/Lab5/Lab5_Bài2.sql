﻿--Nhập vào @Manv, xuất thông tin các nhân viên theo @Manv.
 create proc Bai2_1
  @MaNV varchar(3) 
  as
  begin
	select * 
	from NHANVIEN
	where MANV = @MaNV
  end

exec Bai2_1 '001'

--Nhập vào @MaDa (mã đề án), cho biết số lượng nhân viên tham gia đề án đó
create proc Bai2_2 
	@manv int
as
begin
	select COUNT(MANV) as 'So luong', MADA, TENPHG	
	from NHANVIEN inner join PHONGBAN on NHANVIEN.PHG = PHONGBAN.MAPHG
				  inner join DEAN on DEAN.PHONG = NHANVIEN.PHG
	where MADA=@manv
	GROUP BY TENPHG, MADA
end

exec Bai2_2 10

--Nhập vào @MaDa và @Ddiem_DA (địa điểm đề án), cho biết số lượng nhân viên tham gia đề án có mã đề án là @MaDa và địa điểm đề án là @Ddiem_DA

alter proc Bai2_2 
	@manv int, @Ddiem_DA nvarchar(15)
as
begin 
	select COUNT(MANV) as 'So luong', MADA, TENPHG, DDIEM_DA	
	from NHANVIEN inner join PHONGBAN on NHANVIEN.PHG = PHONGBAN.MAPHG
				  inner join DEAN on DEAN.PHONG = NHANVIEN.PHG
	where MADA=@manv and DDIEM_DA = @Ddiem_DA
	GROUP BY TENPHG, MADA, DDIEM_DA
end

exec Bai2_2 '002', 'Nha Trang'

--Nhập vào @Trphg (mã trưởng phòng), xuất thông tin các nhân viên có trưởng phòng là @Trphg và các nhân viên này không có thân nhân.
create proc Bai2_4 
	@MaTP varchar(5)
as
begin
	select HONV, TENNV, TENPHG, NHANVIEN.MANV, THANNHAN.*
	from NHANVIEN inner join PHONGBAN on PHONGBAN.MAPHG = NHANVIEN.PHG
				  left outer join THANNHAN on THANNHAN.MA_NVIEN = NHANVIEN.MANV
	where THANNHAN.MA_NVIEN is null and TRPHG = @MaTP
end

exec Bai2_4 '008'

--Nhập vào @Manv và @Mapb, kiểm tra nhân viên có mã @Manv có thuộc phòng ban có mã @Mapb hay không
create proc Bai2_5
	@MaNV varchar(5), @MaPB varchar(5)
as
begin
	if exists(select * from NHANVIEN where MANV = @MaNV and PHG = @MaPB)
		print 'Nhân viên: ' + @MaNV+' có trong phòng ban: ' + @MaPB
	else
		print 'Nhân viên: ' + @MaNV+' không có trong phòng ban ' + @MaPB
end

exec Bai2_5 '003','5'